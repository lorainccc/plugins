<?php

/**
 * Provide a public-facing view for the plugin
 *
 * This file is used to markup the public-facing aspects of the plugin.
 *
 * @link       www.lorainccc.edu
 * @since      1.0.0
 *
 * @package    My_Lccc_Info_Feed
 * @subpackage My_Lccc_Info_Feed/public/partials
 */
?>

<!-- This file should primarily consist of HTML with a little bit of PHP. -->
